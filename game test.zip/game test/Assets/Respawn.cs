﻿using UnityEngine;
using System.Collections;

public class Respawn : MonoBehaviour {

	public static int health = 100;
	public LevelManager levelmanager;
	public int health2 = health;

	// Use this for initialization
	void Start () {
		levelmanager = FindObjectOfType<LevelManager> ();
	}

	// Update is called once per frame
	void Update () {
	
		health2 = health;
		if (health > 100) {
			ScoreManager.AddPoints (health - 100);
			ScoreManager.AddPoints (health - 100);
			health = 100;
		}
		if (health <= 0 ) {
			health = 100;
			levelmanager.RespawnPlayer ();
		}
	}
}
