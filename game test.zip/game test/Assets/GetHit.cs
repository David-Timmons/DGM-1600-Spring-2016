﻿using UnityEngine;
using System.Collections;

public class GetHit : MonoBehaviour {

	public int pointsToAdd;

		void OnCollisionEnter2D(Collision2D coll) {
		move player = FindObjectOfType<move>();
		if (player.transform.position.y > transform.position.y + 0.5){
			ScoreManager.AddPoints (pointsToAdd);
			player.GetComponent<Rigidbody2D> ().velocity = new Vector2 (player.GetComponent<Rigidbody2D> ().velocity.x, 8);
			Destroy (gameObject);
			return;
		}
		if (move.invuln == false){
		if (coll.gameObject.name == "player") {
				move.hit = true;
				if (player.transform.position.x > transform.position.x)
					move.right = true;
				else
					move.right = false;
				Respawn.health -= 50;
			}
		}

	}
}

