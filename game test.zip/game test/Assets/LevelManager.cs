﻿using UnityEngine;
using System.Collections;

public class LevelManager : MonoBehaviour {
	
	public GameObject currentCheckPoint;

	//paritcles
	public GameObject sparkle;
	public GameObject blood;

	private move player;

	//respawn delay
	public float respawnDelay;

	
	// Use this for initialization
	void Start () {
		player = FindObjectOfType<move> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	

	public void RespawnPlayer(){
		StartCoroutine ("RespawnPlayerCo");
	}

	public IEnumerator RespawnPlayerCo(){
		//Genereate Death Particles
		Instantiate (blood, player.transform.position, Quaternion.identity);

		//hide player
		player.enabled = false;
		player.GetComponent<Renderer> ().enabled = false;
		player.GetComponent<CircleCollider2D> ().enabled = false;

		//remove velocity from player
		player.GetComponent<Rigidbody2D> ().velocity = new Vector2 (0, 0);

		//remove gravity
		player.GetComponent<Rigidbody2D>().gravityScale = 0;

		//respawn delay
		yield return new WaitForSeconds(respawnDelay);

		//respawn player at current checkpoint
		player.transform.position = currentCheckPoint.transform.position;

		//debug message
		Debug.Log ("Player has Respawned!");

		//show player
		player.enabled = true;
		player.GetComponent<Renderer> ().enabled = true;
		player.GetComponent<CircleCollider2D> ().enabled = true;

		//return gravity
		player.GetComponent<Rigidbody2D>().gravityScale = 1;

		//generate respawn particles
		Instantiate (sparkle, player.transform.position, Quaternion.identity);

		//refill health
		Respawn.health = 100;
	}
	
}
