﻿using UnityEngine;
using System.Collections;

public class RedBeeHit : MonoBehaviour {


	public int pointsToAdd;
	public int speed = -6;
	public int time = 0;
	public int timer = 150;
	int hitTime = 0;



	void OnCollisionEnter2D(Collision2D coll) {
		move player = FindObjectOfType<move>();
		if (player.transform.position.y > transform.position.y + 0.5){
			ScoreManager.AddPoints (pointsToAdd);
			player.GetComponent<Rigidbody2D> ().velocity = new Vector2 (player.GetComponent<Rigidbody2D> ().velocity.x, 8);

			if (hitTime > 24) {
				Destroy (gameObject);
				return;
			}

			this.GetComponent<SpriteRenderer>().color = Color.white;

			if (speed < 0)
				speed = -4;
			else
				speed = 4;
			return;
		}

		if (move.invuln == false){
			if (coll.gameObject.name == "player") {
				move.hit = true;
				if (player.transform.position.x > transform.position.x)
					move.right = true;
				else
					move.right = false;
				Respawn.health -= 50;
			}
		}

	}
	void Update () {
		time ++;
		if (time > timer) {
			time = 0;
			speed = -speed;
		}
		GetComponent<Rigidbody2D> ().velocity = new Vector2 (speed, GetComponent<Rigidbody2D> ().velocity.y );
		if (this.GetComponent<SpriteRenderer> ().color == Color.white && hitTime < 25)
			hitTime += 1;
	}
}