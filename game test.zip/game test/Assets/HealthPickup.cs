﻿using UnityEngine;
using System.Collections;

public class HealthPickup : MonoBehaviour {




	public int healthToAdd;

	void OnTriggerEnter2D (Collider2D other){
		if (other.GetComponent<move> () == null)
			return;

		Respawn.health += healthToAdd;

		Destroy (gameObject);
	}
}