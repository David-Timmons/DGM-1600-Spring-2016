﻿using UnityEngine;
using System.Collections;

public class Launch : MonoBehaviour {

	public int launchSpeed = 25;

	//bool launched = false;
		void OnCollisionEnter2D(Collision2D coll) {
			move player = FindObjectOfType<move>();
		//if (!launched) {
			//launched = true;
			player.GetComponent<Rigidbody2D> ().velocity = new Vector2 (player.GetComponent<Rigidbody2D> ().velocity.x, launchSpeed);
		//}
	}
}