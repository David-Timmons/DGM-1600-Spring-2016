﻿using UnityEngine;
using System.Collections;

public class FlipX : MonoBehaviour {


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	
		if (GetComponent<Rigidbody2D> ().velocity.x > 1) {
			transform.localScale = new Vector3(-1f,1f,1f);
		}

		else if (GetComponent<Rigidbody2D> ().velocity.x < -1) {
			transform.localScale = new Vector3(1f,1f,1f);
	}
}
}