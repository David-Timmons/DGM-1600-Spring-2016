﻿/*using UnityEngine;
using System.Collections;

public class reversex : MonoBehaviour {
	
	public GameObject platformBounce;
	public GameObject wallBounce;

	// Use this for initialization
	void Start () {
		wallBounce = FindObjectOfType<LevelManager> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (platformBounce.transform.position.x == .tansform.position.x ){
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (-GetComponent<Rigidbody2D> ().velocity.x, GetComponent<Rigidbody2D> ().velocity.y);
		}
	}
}
*/